import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(bodyParser.json());

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/api/chat", async (req, res) => {
  try {
    const prompt = req.body.prompt || "Explain the concept";
    const response = await client.responses.create({
      model: "gpt-4.1-mini",
      input: prompt
    });

    let output = "";
    if (response.output && response.output.length) {
      const block = response.output[0];
      if (block.content) output = block.content.map(x => x.text || "").join("\n");
    }

    res.json({ reply: output || "(no reply)" });
  } catch (e) {
    res.json({ reply: "Backend error. Check API key." });
  }
});

app.get("/", (req, res) => res.send("Punjab Edu Backend Running"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log("Backend started on " + PORT));
